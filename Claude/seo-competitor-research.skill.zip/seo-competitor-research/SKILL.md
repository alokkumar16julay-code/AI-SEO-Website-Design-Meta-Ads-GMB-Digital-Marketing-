---
name: seo-competitor-research
description: Runs live SERP/competitor research for a target keyword — searches the top-ranking pages, fetches and analyzes them, and reports content gaps, missing entities, weak sections, and a recommended content structure. Only use when the user explicitly invokes this skill by name (e.g. "use SEO competitor research skill") — do not trigger on general SEO or keyword questions.
---

# SEO Competitor Research

Produces a research brief for a target keyword by analyzing the actual top-ranking pages, not general knowledge. This is meant to feed into `seo-article-master-writer`, but can be run standalone.

**Trigger only on explicit invocation.** If the user just mentions SEO, keywords, or asks for an article without invoking this skill by name, do not use it.

## Output format

Plain text / Markdown only, delivered directly in the chat response. Never create a .docx, .html, or other file for this — the user copies the text straight out of the conversation. No artifacts.

## Workflow

1. **Clarify inputs if missing.** You need: the primary keyword, and optionally target location/language, and any specific competitor URLs the user wants included. If the user gave a keyword but nothing else, proceed — don't block on secondary details.

2. **Search.** Use `web_search` with the primary keyword (and 1-2 close variants) to find the current top-ranking pages. Look at the top 8-10 organic results, ignoring ads, video packs, and obviously irrelevant results.

3. **Fetch and read.** Use `web_fetch` on the top 5-7 most relevant ranking URLs (skip huge sites you can't meaningfully parse, like giant forums with no clear article). For each one, note:
   - Article structure (H2/H3 headings as best you can infer)
   - Word count (rough)
   - What questions it answers
   - What it's missing or handles weakly
   - Entities it references (people, brands, products, tools, locations)
   - Content format used (listicle, guide, comparison, FAQ, etc.)

4. **Synthesize.** Don't just summarize each competitor one by one — cross-reference them to find the real gaps: what does NO top-ranking page cover well? What questions show up in "People Also Ask" style patterns or forums but aren't answered by the top results?

5. **Report** using this structure:

```
# Competitor Research: [keyword]

## Search Intent
[1-2 sentences: what is the searcher actually trying to do/find]

## Top-Ranking Pages Analyzed
[Numbered list: URL — one-line note on angle/format]

## Content Coverage Summary
[Table or list: topic/subtopic vs which competitors cover it]

## Content Gaps (Information Gain Opportunities)
[Bullet list of things no competitor covers well — this is the most
important section, it's what lets a new article outrank them]

## Missing/Weak Entities
[People, brands, tools, locations, concepts that should be mentioned
but aren't well-covered anywhere]

## Recommended Structure
[H2/H3 outline that beats what's currently ranking, based on the gaps above]

## Notes
[Anything else relevant — format patterns, tone patterns, red flags
like thin AI-generated competitor content, etc.]
```

## Guardrails

- Never fabricate what a competitor page says — if `web_fetch` fails or the content is thin/unreadable, say so rather than guessing.
- Don't quote competitor text at length; paraphrase everything (standard copyright practice) and keep any direct phrase under ~10 words if used at all.
- If fewer than 4-5 pages are fetchable, note that the research is based on a smaller sample.
